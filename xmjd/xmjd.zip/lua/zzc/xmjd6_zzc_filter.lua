local core = require("zzc.xmjd6_zzc_core")
local COLLECT_CANDIDATE_LIMIT = 30


local length_inputs = {
    ["3"] = 3, ["4"] = 4, ["5"] = 5, ["6"] = 6,
    ["三"] = 3, ["四"] = 4, ["五"] = 5, ["六"] = 6,
}
local function split_length_input(input)
    input = input or ""
    local last_char = input
    local prefix = ""
    if utf8 and utf8.len and utf8.len(input) and utf8.len(input) > 1 then
        local start = utf8.offset(input, -1)
        last_char = start and input:sub(start) or input
        prefix = start and input:sub(1, start - 1) or ""
    elseif #input > 1 then
        last_char = input:sub(-1)
        prefix = input:sub(1, -2)
    end
    return prefix, length_inputs[last_char]
end

local function is_cjk_text(text)
    return text and text:match("[\228-\233][\128-\191][\128-\191]") ~= nil
end

local is_real_candidate = core.is_real_candidate

local function is_collect_candidate(cand)
    return cand
        and cand.text
        and cand.text ~= ""
        and cand.text:sub(1, 1) ~= "~"
end

local with_reminder

local function maybe_finalize_from_input(ctx, input_text, env, input)
    local prefix, len = split_length_input(input_text)
    local prop_stage = ctx and ctx.get_property and ctx:get_property("_xmjd6_zzc_stage") or ""
    local prop_word = ctx and ctx.get_property and ctx:get_property("_xmjd6_zzc_word") or ""
    local prop_items = ctx and ctx.get_property and ctx:get_property("_xmjd6_zzc_items") or ""
    local literal_prefix = prefix or ""
    local has_literal_trigger = literal_prefix:sub(1, 1) == "\\"
    if has_literal_trigger then
        literal_prefix = literal_prefix:sub(2)
    end
    local literal_length_input = has_literal_trigger and literal_prefix ~= "" and is_cjk_text(literal_prefix) and not literal_prefix:match("^[A-Za-z;']+$")
    if not len or (core.current_stage() == "off" and prop_stage == "" and prop_word == "" and not literal_length_input) then return false end
    if ctx and ctx.set_property then ctx:set_property("_xmjd6_zzc_len", tostring(len)) end
    if (not core.state_items or #core.state_items == 0) and prop_items ~= "" then
        local items = core.deserialize_items(prop_items)
        if items and #items > 0 then
            core.set_state_items(items)
            if core.current_stage() == "off" then core.set_current_stage("collect") end
        end
    end
    if prefix:sub(1, 1) == "\\" then
        prefix = prefix:sub(2)
    end
    if prefix and prefix ~= "" then
        local current = core.buffer_word() or ""
        if current == "" or prefix:sub(1, #current) ~= current then
            if is_cjk_text(prefix) and not prefix:match("^[A-Za-z;']+$") then
                local items, err = core.items_from_text(prefix)
                if not items and err and tostring(err):match("^ambiguous_char:") then
                    items = core.raw_items_from_text(prefix)
                end
                if not items then return false end
                core.set_state_items(items)
            else
                if not input then return false end
                local first
                for cand in input:iter() do
                    first = cand
                    break
                end
                if not is_real_candidate(first) or not is_cjk_text(first.text) then return false end
                local ok = core.append_candidate_text(first.text, nil)
                if not ok then return false end
            end
        end
    end
    local word = core.buffer_word() or ""
    if word == "" and prop_word ~= "" then
        word = prop_word
        if not core.state_items or #core.state_items == 0 then
            local items = core.items_from_text(word)
            if items then core.set_state_items(items) end
        end
    end
    if word == "" then return false end
    local direct_code = prefix and prefix:match("^[A-Za-z;']+$") and prefix or nil
    local code
    if direct_code and #direct_code == len then
        code = core.save_word_at_code(core.state_items or {}, direct_code)
    else
        code = core.enqueue_pending(core.state_items or {}, len)
    end
    if not code then
        local choices = core.code_choices_for_text(word, len, 9)
        if choices and choices[1] then
            if #choices == 1 then
                local choice = choices[1]
                code = core.save_word_at_code(choice.items or core.state_items or {}, choice.code)
            end
        end
        if not code and choices and choices[1] then
            local rows = {}
            for _, choice in ipairs(choices) do
                rows[#rows + 1] = choice.word .. "\t" .. choice.code
            end
            if ctx and ctx.set_property then
                ctx:set_property("_xmjd6_zzc_stage", "resolve_code")
                ctx:set_property("_xmjd6_zzc_word", word)
                ctx:set_property("_xmjd6_zzc_items", core.serialize_items(core.state_items or {}))
                ctx:set_property("_xmjd6_zzc_len", tostring(len))
                ctx:set_property("_xmjd6_zzc_mode", "make")
                ctx:set_property("_xmjd6_zzc_cmd_candidates", table.concat(rows, "\n"))
            end
            core.set_current_stage("resolve_code")
            return false
        end
    end
    if not code then
        return false
    end
    ctx:clear()
    core.set_state_items({})
    core.set_current_stage("off")
    if ctx and ctx.set_property then
        ctx:set_property("_xmjd6_zzc_stage", "")
        ctx:set_property("_xmjd6_zzc_word", "")
        ctx:set_property("_xmjd6_zzc_items", "")
        ctx:set_property("_xmjd6_zzc_len", "")
        ctx:set_property("_xmjd6_zzc_finalize", "1")
    end
    env.engine:commit_text(word)
    return true
end

local function state_candidate(ctx, code)
    local prop_stage = ctx and ctx.get_property and ctx:get_property("_xmjd6_zzc_stage") or ""
    local prop_word = ctx and ctx.get_property and ctx:get_property("_xmjd6_zzc_word") or ""
    local prop_mode = ctx and ctx.get_property and ctx:get_property("_xmjd6_zzc_mode") or ""
    local prop_display = ctx and ctx.get_property and ctx:get_property("_xmjd6_zzc_display") or ""
    local prop_target = ctx and ctx.get_property and ctx:get_property("_xmjd6_zzc_target") or ""
    local prop_items = ctx and ctx.get_property and ctx:get_property("_xmjd6_zzc_items") or ""
    if core.current_stage() == "off" and prop_stage == "" and prop_word == "" then return nil end
    local word = core.buffer_word()
    local pending_code = ""
    if prop_stage == "collect" and code and code ~= "" and code ~= "\\" then
        local prefix = prop_mode == "append" and (prop_target .. "\\+") or (prop_target .. "\\")
        if prop_target ~= "" and code:sub(1, #prefix) == prefix then
            pending_code = code:sub(#prefix + 1)
        else
            pending_code = code:sub(1, 1) == "\\" and code:sub(2) or code
        end
        if pending_code and not pending_code:match("^[A-Za-z;']+$") then
            pending_code = ""
        end
    end
    if (prop_mode == "delete" or prop_mode == "promote" or prop_mode == "restore") and prop_stage == "command_wait" and prop_target ~= "" then
        word = prop_target
    elseif prop_mode == "undo" and prop_stage == "command_wait" then
        word = prop_display ~= "" and prop_display or "-"
    elseif prop_mode == "shorten" and prop_display ~= "" and prop_stage == "shorten_wait" then
        word = prop_display
    elseif prop_stage == "resolve_notice" and prop_display ~= "" then
        word = prop_display
    elseif prop_mode == "append" and prop_target ~= "" and prop_stage == "collect" then
        word = prop_word
    elseif prop_mode == "replace" and prop_stage == "collect" and prop_target ~= "" then
        word = prop_word
    elseif prop_mode == "replace" and prop_display ~= "" and (prop_stage == "replace_wait" or prop_items == "") then
        word = prop_display
    elseif word == "" then
        word = prop_word
    end
    if (not word or word == "")
        and not (prop_mode == "append" and prop_target ~= "" and prop_stage == "collect")
        and not (prop_mode == "replace" and prop_target ~= "" and prop_stage == "collect") then return nil end
    local text
    if prop_mode == "delete" and prop_stage == "command_wait" and prop_target ~= "" then
        text = prop_target .. "\\-" .. (prop_display or "")
    elseif prop_mode == "restore" and prop_stage == "command_wait" and prop_target ~= "" then
        text = prop_target .. "\\++" .. (prop_display or "")
    elseif prop_mode == "promote" and prop_stage == "command_wait" and prop_target ~= "" then
        text = prop_target .. "\\" .. (prop_display or "")
    elseif prop_mode == "undo" and prop_stage == "command_wait" then
        local display = prop_display or ""
        local prefix = prop_target ~= "" and (prop_target .. "\\") or "\\"
        if display:match("^[!！]+$") then
            text = prefix .. display
        else
            text = prefix .. "-" .. display
        end
    elseif prop_mode == "shorten" and prop_display ~= "" and prop_stage == "shorten_wait" then
        text = word .. "\\<"
    elseif prop_stage == "resolve_notice" then
        text = word
    elseif prop_mode == "append" and prop_target ~= "" and prop_stage == "collect" then
        text = prop_target .. "\\+" .. (word or "")
    elseif prop_mode == "replace" and prop_stage == "collect" and prop_target ~= "" then
        text = prop_target .. "\\" .. (word or "") .. (pending_code or "")
    elseif prop_mode == "replace" and prop_display ~= "" and (prop_stage == "replace_wait" or prop_items == "") then
        text = word .. "\\"
    elseif prop_stage == "collect" and pending_code ~= "" then
        text = "\\" .. word .. pending_code
    else
        text = "\\" .. word
    end
    local end_pos = #code
    if end_pos < 1 then end_pos = 1 end
    local comment = "自造词ing"
    if prop_stage == "resolve_notice" and prop_target ~= "" then
        comment = "已选编码 " .. prop_target
    end
    local cand_text = text
    if prop_stage == "collect" and prop_mode == "replace" and prop_target ~= "" then
        cand_text = text
    elseif prop_stage == "collect" and word ~= "" and pending_code ~= "" then
        cand_text = word
    end
    local cand = Candidate("zzc_state", 0, end_pos, cand_text, comment)
    if prop_stage == "collect" and prop_mode == "replace" and prop_target ~= "" then
        cand.preedit = text
    elseif cand_text ~= text then
        cand.preedit = text
    end
    cand.quality = 10000
    return cand
end

local function collect_lookup_code(ctx, code)
    local prop_stage = ctx and ctx.get_property and ctx:get_property("_xmjd6_zzc_stage") or ""
    local prop_mode = ctx and ctx.get_property and ctx:get_property("_xmjd6_zzc_mode") or ""
    local prop_target = ctx and ctx.get_property and ctx:get_property("_xmjd6_zzc_target") or ""
    if prop_stage == "collect"
        and (prop_mode == "replace" or prop_mode == "append")
        and prop_target ~= "" then
        local prefix = prop_mode == "append" and (prop_target .. "\\+") or (prop_target .. "\\")
        if tostring(code or ""):sub(1, #prefix) == prefix then
            return tostring(code or ""):sub(#prefix + 1)
        end
        if tostring(code or ""):sub(1, 1) == "\\" then
            return tostring(code or ""):sub(2)
        end
    end
    return code
end

local function yield_restore_candidates(ctx, code)
    local prop_stage = ctx and ctx.get_property and ctx:get_property("_xmjd6_zzc_stage") or ""
    local prop_mode = ctx and ctx.get_property and ctx:get_property("_xmjd6_zzc_mode") or ""
    if prop_stage ~= "command_wait" or prop_mode ~= "restore" then return false end
    local rows_text = ctx and ctx.get_property and ctx:get_property("_xmjd6_zzc_cmd_candidates") or ""
    local idx = 0
    local yielded = false
    for line in rows_text:gmatch("[^\n]+") do
        idx = idx + 1
        local cand = Candidate("zzc_restore", 0, #code, line, "恢复")
        cand.quality = 10070 - idx
        yield(with_reminder(cand))
        yielded = true
    end
    return yielded
end

local function yield_code_choice_candidates(ctx, code)
    local prop_stage = ctx and ctx.get_property and ctx:get_property("_xmjd6_zzc_stage") or ""
    if prop_stage ~= "resolve_code" then return false end
    local rows_text = ctx and ctx.get_property and ctx:get_property("_xmjd6_zzc_cmd_candidates") or ""
    local idx = 0
    local yielded = false
    local zero_width_space = string.char(0xE2, 0x80, 0x8B)
    for line in rows_text:gmatch("[^\n]+") do
        local word, choice_code = line:match("^([^\t]+)\t([^\t%s]+)")
        if word and choice_code then
            idx = idx + 1
            local display_word = word
            if idx > 1 then
                display_word = word .. zero_width_space:rep(idx - 1)
            end
            local cand = Candidate("zzc_code_choice", 0, #code, display_word, choice_code)
            cand.quality = 10080 - idx
            yield(cand)
            yielded = true
        end
    end
    return yielded
end

local function with_preedit(cand, preedit_text)
    if not cand or not preedit_text or preedit_text == "" then return cand end
    local ok, nc = pcall(Candidate, cand.type or "derived", cand.start, cand._end, cand.text or "", cand.comment or "")
    if not ok or not nc then
        cand.preedit = preedit_text
        cand._xmjd6_zzc_preedit_only = true
        return cand
    end
    nc.preedit = preedit_text
    nc.quality = cand.quality
    nc._xmjd6_zzc_preedit_only = true
    return nc
end

with_reminder = function(cand)
    if not cand or not core.take_reminder_comment then return cand end
    local comment = core.take_reminder_comment()
    if comment and comment ~= "" then
        cand.comment = comment
    end
    return cand
end

local function yield_zzc_cover_candidates(input_text, cover, preedit_text)
    cover = cover or core.zzc_cover_for_input(input_text)
    if not cover then return nil end
    local first = true
    local yielded = false
    if cover.rows then
        for _, row in ipairs(cover.rows) do
            local cand = Candidate("zzc_cover", 0, #input_text, row.word, "自造词")
            cand.quality = 10060
            if first then
                cand.preedit = preedit_text or cand.preedit
                first = false
            end
            yield(with_reminder(cand))
            yielded = true
        end
    end
    if not yielded and not (cover.append_rows and cover.append_rows[1]) then return nil end
    return cover
end

local function yield_append_candidates(input_text, cover)
    if not cover or not cover.append_rows then return false end
    local yielded = false
    for _, row in ipairs(cover.append_rows) do
        local cand = Candidate("zzc_append", 0, #input_text, row.word, "自造词")
        cand.quality = 8000
        yield(with_reminder(cand))
        yielded = true
    end
    return yielded
end

local function yield_empty_state_candidate(ctx, code, preedit_text)
    local text = preedit_text or ""
    local cand = Candidate("zzc_state", 0, #text, text, "")
    cand.preedit = text
    cand.quality = 10000
    yield(cand)
    return true
end

local function yield_input_candidates(input, skip_first, real_only, preedit_text)
    local skipped = false
    local first = true
    local yielded = false
    for cand in input:iter() do
        if not real_only or is_real_candidate(cand) then
            if skip_first and not skipped then
                skipped = true
            else
                if first then
                    yield(with_preedit(cand, preedit_text))
                    first = false
                else
                    yield(cand)
                end
                yielded = true
            end
        end
    end
    return yielded
end

local function yield_filtered_input_candidates(input, cover, preedit_text)
    local first = true
    local yielded = false
    for cand in input:iter() do
        if is_real_candidate(cand) then
            if not cover
                or not cand.text
                or (not cover.keep_words[cand.text] and not cover.hide_words[cand.text]) then
                if first then
                    yield(with_preedit(cand, preedit_text))
                    first = false
                else
                    yield(cand)
                end
                yielded = true
            end
        else
            yield(cand)
            yielded = true
        end
    end
    return yielded
end

local function filter(input, env)
    if not core.allowed(env) then
        yield_input_candidates(input, false)
        return
    end
    local ctx = env.engine.context
    local code = ctx and ctx.input or ""
    local prop_stage = ctx and ctx.get_property and ctx:get_property("_xmjd6_zzc_stage") or ""
    local prop_mode = ctx and ctx.get_property and ctx:get_property("_xmjd6_zzc_mode") or ""
    if maybe_finalize_from_input(ctx, code, env, input) then
        return
    end
    local state_cand = state_candidate(ctx, code)
    local collect_with_code = state_cand
        and prop_stage == "collect"
        and code ~= ""
        and code ~= "\\"
    local collect_preedit = collect_with_code and (state_cand.preedit or state_cand.text) or nil
    if yield_code_choice_candidates(ctx, code) then
        return
    end
    if state_cand and code == "" then
        yield(with_reminder(state_cand))
        return
    end
    if code == "\\" and state_cand then
        yield(with_reminder(state_cand))
        return
    end
    if state_cand and prop_mode == "restore" and prop_stage == "command_wait" then
        yield(with_reminder(state_cand))
        yield_restore_candidates(ctx, code)
        return
    end
    if state_cand and (prop_mode == "delete" or prop_mode == "promote" or prop_mode == "undo") and prop_stage == "command_wait" then
        yield(with_reminder(state_cand))
        return
    end
    if state_cand and prop_mode == "shorten" and prop_stage == "shorten_wait" then
        yield(with_reminder(state_cand))
        return
    end
    if state_cand and prop_stage == "resolve_notice" then
        yield(with_reminder(state_cand))
        return
    end
    if state_cand and prop_mode == "replace" and prop_stage == "replace_wait" then
        yield(with_reminder(state_cand))
        return
    end
    if code ~= "" and (not state_cand or collect_with_code) then
        local lookup_code = collect_with_code and collect_lookup_code(ctx, code) or code
        local cover = core.zzc_order_for_input and core.zzc_order_for_input(lookup_code) or core.zzc_cover_for_input(lookup_code)
        if cover and cover.has_order then
            local yielded = yield_zzc_cover_candidates(code, cover, collect_preedit) ~= nil
            yielded = yield_append_candidates(code, cover) or yielded
            yielded = yield_filtered_input_candidates(input, cover, collect_preedit) or yielded
            if collect_with_code and not yielded then
                yield_empty_state_candidate(ctx, lookup_code, collect_preedit)
            end
            return
        end
        cover = yield_zzc_cover_candidates(code, cover, collect_preedit)
        if cover then
            local yielded = cover.rows and cover.rows[1] ~= nil
            if not yielded then
                yielded = yield_filtered_input_candidates(input, cover, collect_preedit) or yielded
            end
            yielded = yield_append_candidates(code, cover) or yielded
            if cover.rows and cover.rows[1] then
                yielded = yield_filtered_input_candidates(input, cover, collect_preedit) or yielded
            end
            if collect_with_code and not yielded then
                yield_empty_state_candidate(ctx, lookup_code, collect_preedit)
            end
            return
        end
        cover = core.zzc_cover_for_input and core.zzc_cover_for_input(lookup_code) or nil
        if cover and cover.hide_words then
            local yielded = yield_filtered_input_candidates(input, cover, collect_preedit)
            if collect_with_code and not yielded then
                yield_empty_state_candidate(ctx, lookup_code, collect_preedit)
            end
            return
        end
    end
    if collect_with_code and collect_lookup_code(ctx, code) ~= code then
        return
    end
    if code == "" then
        if state_cand then yield(with_reminder(state_cand)) end
        for cand in input:iter() do yield(cand) end
        return
    end
    local yielded = yield_input_candidates(input, false, false, collect_preedit)
    if collect_with_code and not yielded then
        yield_empty_state_candidate(ctx, code, collect_preedit)
    end
end

return filter

